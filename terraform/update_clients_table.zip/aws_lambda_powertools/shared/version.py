"""Exposes version constant to avoid circular dependencies."""

VERSION = "2.17.0"
